% MLC Accelerometer V2.0
% How to read accelerometer sensor data.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--------------------------------------------------------------------------
%% Init classes and settings
addpath('MLCMatlabLayer');
mlcInitMLC();
close all;

% Configuration
N = 1000;          % Number of values to read
flagStreaming = 1; % If streaming mode is set, readout is faster (also less latency)

%% Connecting to Android device
dispDemo('accelerometer');
android = mlcStartDefaultServer();

%% If device is connected, test all function available
if (mlcIsConnected(android))
    
    %Set display
    mlcLaunchSensorView(android);
    mlcSetOrientation(android,'portrait');
    mlcLockScreenDimming(android, true);
    
    info = mlcSensorGetInfo(android,'accelerometer');
    
    % Only start reading if accelerometer is available
    if (~strcmp(info,'No sensor'))
        
        % Enter streaming mode, if required
        if (flagStreaming == 1)
            mlcSensorStreaming(android, 'accelerometer', 4);
        end
        
        %Prepare for ploting
        figure(1);
        drawnow;
        
        xdata = zeros(1,N);
        ydata = zeros(1,N);
        zdata = zeros(1,N);
        
        %Read sensor data and plot results
        for k1 = 1:N
            sensorData = mlcSensorRead(android, 'accelerometer');
            
            xdata(k1) = sensorData(1);
            ydata(k1) = sensorData(2);
            zdata(k1) = sensorData(3);
            
            plot([xdata(1:k1); ydata(1:k1); zdata(1:k1)].');
            ylim([-10,10]);
            xlim([1,N]);
            grid on;
            drawnow;
        end
        
        % Close streaming mode
        if (flagStreaming == 1)
            mlcSensorStreaming(android, 'accelerometer', 0);
        end
        
        %Unlock screen dimming and close connection
        mlcLockScreenDimming(android, false);
        mlcClose(android);
    else
        disp('Sorry, no accelerometer available on your device.')
    end
end