function [ version ] = mlcGetAppVersion(MLCapp)
% Retrieve app version
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% version ... Version of the app running on your Android device
%--------------------------------------------------------------------------
    version=char(MLCapp.getAppVersion());
end

