function [ isStillThere ] = mlcIsStillThere(MLCapp)
% Aks app if she is still there, and reports result
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% isStillThere ... true when app is responding
%                  false when app is not responding, probably
%                        the connection was lost!
%--------------------------------------------------------------------------
    isStillThere = MLCapp.isAppStillThere();
end