function [ status ] = mlcFCVError(MLCapp, line)
% Write a error (???+red) to the FullControll interface
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% line ....... Line to write to the FullControl interface
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.writeError(line);
end