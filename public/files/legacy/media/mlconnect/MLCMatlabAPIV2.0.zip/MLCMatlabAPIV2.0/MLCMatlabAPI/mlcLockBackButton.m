function [ status ] = mlcLockBackButton(MLCapp, lock)
% Lock the back button for current view
% Only for current view, will not apply to new views launched after lock
% or for views "behind" the current view
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% lock ....... true  - lock back button
%              false - unlock back button
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.lockBackButton(lock);
end