function [ MLCapp ] = mlcStartServer(serverName, port, timeout, bufferSize, retry)
% Start an MLC Server for an Android device to connect
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% serverName ... Name of your Server (e.g. 'Peter's machine')
% port ......... 1024 - 49151 (Android device has to use same port)
% timeout ...... in ms (recommendation somewhere between 1000-30000)
% bufferSize ... in bytes, 1024*1024 should do
% retry ........ 0 will wait for a connection forever
%                1 will wait for a connection 1 x timeout
%                n will wait for a connection n x timeout
%--- OUTPUT ---------------------------------------------------------------
% MLCapp ....... MLCAndroidInterface Java object for further use
%--------------------------------------------------------------------------
    
    % Check if the Interface manager exists (created in mlcInitMLC())
    if(isappdata(0, 'mlcifm') == 0)
         msg=['Could not find the Interface Manager.', char(10), ...
              'Please make sure you have called mlcInitMLC()!'];
         error(msg);
    end
    
    % Get Interface Manager and create interface
    mlcifm = getappdata(0, 'mlcifm');
    MLCapp = mlcifm.createInterface(serverName, port, timeout, bufferSize);
    % Wait for incoming connection
    flagEnd = 0;
    while flagEnd == 0
        retry = retry-1;
        status = MLCapp.open(false);
        if status ~= 0 || retry == 0;
            flagEnd = 1;
        end
        if (retry == -1)
            retry = 0;
        end
    end
    
    appversion = mlcGetAppVersion(MLCapp);
    
    if (status ~= 1)
        MLCapp.close();
    end

    % Error handling
    if (status == com.chschmid.MLCServer.MLCAndroidInterface.ERROR_APP_VERSION_INCOMPATIBLE)
        if (isempty(appversion))
            appversion = '< 2.0';
        end
        msg=['The app version running on your mobile device is too old for your MLC Matlab API version', char(10), ...
             '         Android app version: ', appversion, char(10), ...
             'MLC Matlab interface version: ', mlcGetInterfaceVersion(MLCapp),char(10), ...
             'Please update the app on your Android device!'];
        %MLCapp = [];
        error(msg);
    end
end

