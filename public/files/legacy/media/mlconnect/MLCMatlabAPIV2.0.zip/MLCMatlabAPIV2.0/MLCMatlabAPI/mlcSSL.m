function [ status ] = mlcSSL(MLCapp, sslStatus)
% Activate or deactivate SSL/TLS encryption. By default a connection will
% not be protected by SSL. Note that only the paid edition of MLConnect
% supports SSL. - Returns 2 if SSL is active.
% And the best of all: You can activate and deativate SSL/TLS anytime.
% Doing so before checking the password is a good idea.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ...... MLCAndroidInterface java object
% sslStatus ... true .... will activate SLL/TLS
%               false ... will deactivate SLL/TLS
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status - returns 2 if SSL/TLS is activated
%--------------------------------------------------------------------------
    status = MLCapp.getStatus();
    
    if (MLCapp.isFreeEdition())
        msg = ['MLConnect API ', mlcGetInterfaceVersion(MLCapp), ':',char(10), ...
               'MLConnect Free Edition does not support SSL/TLS encryption', char(10), ...
               'SSL/TLS was not activated!'];
        warning('MLConnect:SSLTLS', msg);
        drawnow;
    else
        % Believe me, you can make your Matlab code go into this branch
        % but the app will still not accept SSL, if you have the free
        % version
        
        if (sslStatus)
            MLCapp.activateSSL();
            sslActivated = 1;
        else
            MLCapp.deactivateSSL();
            sslActivated = 0;
        end
        
        status = MLCapp.getStatus();
        if (sslActivated == 1 && status == 1)
            status = 2;
        end
    end
end
