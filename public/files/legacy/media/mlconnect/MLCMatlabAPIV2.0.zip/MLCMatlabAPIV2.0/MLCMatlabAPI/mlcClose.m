function [ status ] = mlcClose(MLCapp)
% Close the open connection to MLCapp = Android device
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... should be 0 afer connection has been closed
%--------------------------------------------------------------------------
    status=MLCapp.close();
end

