function [ userInput ] = mlcFCVWaitForInput(MLCapp, retry)
% Wait for input from the app user
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java objec
% retry .... 0 will wait for a connection forever
%            1 will wait for a connection 1 x timeout
%            n will wait for a connection n x timeout
%--- OUTPUT ---------------------------------------------------------------
% userInput ... String with the user input
%--------------------------------------------------------------------------
    waiting=true;
    while waiting
        retry=retry-1;
        userInput=char(MLCapp.waitForFCVUserInput());
        if ~isempty(userInput) || retry==0
           waiting=false;
        end
        if (retry==-1)
            retry=0;
        end
    end
end

