function [ isConnected ] = mlcIsConnected(MLCapp)
% Is an app connected?
% Might not be that fast in detecting if the connection has been lost, try
% mlcIsStillThere instead.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% isConnected ... true when app is connected
%                 false when app is not connected
%--------------------------------------------------------------------------
    if (MLCapp.getStatus() == com.chschmid.MLCServer.MLCAndroidInterface.CONNECTED)
        isConnected = true;
    else
        isConnected = false;
    end
end