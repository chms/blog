function [ status ] = mlcSensorStreaming(MLCapp, sensor, updateRate)
% Activates streaming mode for sensor value, which is faster than using
% mlcSensorRead without streaming mode.
% mlcSensorRead without streaming mode:
%  send request -> wait for app responds -> return value
% mlcSensorRead in streaming mode:
%  App streams data continuously -> return latest value
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% sensor ....... The following sensors are supported:
%                'accelerometer'
%                'orientation'
%                'gyroscope'
%                'proximity'
%                'light'
%                'magneticfield'
%                'pressure'
%                'temperature'
% updateRate ... 0 ... deactivate streaming
%                1 ... lowest update rate
%                2
%                3
%                4 ... highest update rate
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    if (MLCapp.isValidSensor(sensor))
        if (updateRate == 0)
            MLCapp.stopSensorStreaming(sensor);
        else
            MLCapp.startSensorStreaming(sensor, 4 - updateRate);
        end
    else
        msg=['MLC Matlab interface version ', mlcGetInterfaceVersion(MLCapp), ':',char(10), ...
             '''',sensor,'''',' streaming mode command faild. Sensor unknown.'];
        error(msg);
    end
    
    status = MLCapp.getStatus();
end