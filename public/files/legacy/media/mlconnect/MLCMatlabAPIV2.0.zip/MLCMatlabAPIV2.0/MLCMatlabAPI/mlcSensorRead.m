function [ sensorValue ] = mlcSensorRead(MLCapp, sensor)
% Read out Android device sensor values. If using mlcReadSensor alone is
% too slow for your application consider activating streaming mode through
% mlcSensorStreaming before reading sensor vales.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% sensor ... The following sensors are supported:
%            'accelerometer'
%            'orientation'
%            'gyroscope'
%            'proximity'
%            'light'
%            'magneticfield'
%            'pressure'
%            'temperature'
%--- OUTPUT ---------------------------------------------------------------
% sensorValue ... Sensor data. Dimensions depend on the sensor type
%                 i.e. 3x1 for orientation and 1x1 for temperature.
%--------------------------------------------------------------------------
    sensorValue = MLCapp.getSingleSensorValue(sensor);
    if (isempty(sensorValue))
         msg=['MLC Matlab interface version ', mlcGetInterfaceVersion(MLCapp), ':',char(10), ...
              '''',sensor,'''',' readout failed. Check if the requested sensor is available'];
         error(msg);
    end
end