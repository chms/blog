function [ status ] = mlcLaunchSensorView(MLCapp)
% Launch SensorView interface for showing which sensors are available and
% which are being interrogated
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.launchView('SensorView');
end

