function [ status ] = mlcLockScreenDimming(MLCapp, lock)
% Lock/Unlocks the Android auto screen dimming function.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% lock ....... true  - lock screen dimming, screen won't turn off
%              false - unlock screen dimming
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.lockScreenDimming(lock);
end