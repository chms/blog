function [ status ] = mlcSetOrientation(MLCapp, orientation)
% Set screen orientation
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% orientation ... 'auto', 'portrait', 'landscape'
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.setOrientation(orientation);
    if (status == com.chschmid.MLCServer.MLCAndroidInterface.ERROR_UNKNOWN_SCREEN_ORIENTATION)
         msg=['MLC Matlab interface version ', mlcGetInterfaceVersion(MLCapp), ':',char(10), ...
              'Unknown screen orientation requested'];
         error(msg);
    end
end