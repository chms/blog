function [ status ] = mlcFCV2ClearFigure(MLCapp, figID)
% Clear a FullControlView2 Figure (in the Figure window) or all figures
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
% figID .... ID of figure to clear. 0 for clearing the complete list
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.clearFigure(figID);
end