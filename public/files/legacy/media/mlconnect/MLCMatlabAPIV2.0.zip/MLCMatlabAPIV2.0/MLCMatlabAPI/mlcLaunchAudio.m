function [ status ] = mlcLaunchAudio(MLCapp)
% Play an audio alert
% Of course Android media volume has to be on for it to be heard
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.launchAudio();
end

