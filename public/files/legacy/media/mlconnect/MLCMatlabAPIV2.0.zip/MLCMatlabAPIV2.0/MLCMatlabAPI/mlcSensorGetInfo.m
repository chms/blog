function [ sensorInfo ] = mlcSensorGetInfo(MLCapp, sensor)
% Check if sensor is available, and return sensor name and vendor
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% sensor ... The following sensors are supported:
%            'accelerometer'
%            'orientation'
%            'gyroscope'
%            'proximity'
%            'light'
%            'magneticfield'
%            'pressure'
%            'temperature'
%--- OUTPUT ---------------------------------------------------------------
% info ... 1 'No sensor' when no sensor is available
%            '<Name>, <Vendor>' when sensor is avilable
%            'Unknown sensor' on error
%--------------------------------------------------------------------------
    sensorInfo =  char(MLCapp.getSensorInfo(sensor));
    if (strcmp(sensorInfo,char(com.chschmid.MLCServer.MLCAndroidInterface.ERROR_UNKNOWN_SENSOR)))
         msg=['MLC Matlab interface version ', mlcGetInterfaceVersion(MLCapp), ':',char(10), ...
              '''',sensor,'''', ' invalid sensor type'];
         error(msg);
    end
end