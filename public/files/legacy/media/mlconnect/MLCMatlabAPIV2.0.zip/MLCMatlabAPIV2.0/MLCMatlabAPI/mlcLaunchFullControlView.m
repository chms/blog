function [ status ] = mlcLaunchFullControlView(MLCapp)
% Launch FullControl graphical user interface
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.launchView('FullControlView');
end