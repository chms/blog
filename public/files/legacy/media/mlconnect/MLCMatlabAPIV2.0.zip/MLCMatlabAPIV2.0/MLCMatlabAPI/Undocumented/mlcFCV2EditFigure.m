function [ status ] = mlcFCV2EditFigure(MLCapp, figID, thumbnailFile, file, title)
% Lets you add or edit a figure in the figure list of the FCV2 GUI
% You will have to upload the figures before adding them to the list using
% mlcWriteFile.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp .......... MLCAndroidInterface java object
% figID ........... ID of figure to add / edit.
% thumbnailFile ... Thumbnail filename - has to be on device already
%                   (see mlcWriteFile)
% file ............ Image filename - has to be on device already
%                   (see mlcWriteFile)
% title ........... Text to display next to thumbnail
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.editFigure(figID, thumbnailFile, file, title);
end