function [ status ] = mlcFCVUnlockUserInput(MLCapp)
% Unlock the user input (locked after every input)
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status=MLCapp.unlockUserInput();
end

