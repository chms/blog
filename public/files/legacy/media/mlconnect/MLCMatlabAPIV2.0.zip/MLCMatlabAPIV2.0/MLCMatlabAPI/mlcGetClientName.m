function [ clientName ] = mlcGetClientName(MLCapp)
% Get android device name
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% clientName ... Name provided by the Android device connected
%--------------------------------------------------------------------------
    clientName=char(MLCapp.getClientName());
end

