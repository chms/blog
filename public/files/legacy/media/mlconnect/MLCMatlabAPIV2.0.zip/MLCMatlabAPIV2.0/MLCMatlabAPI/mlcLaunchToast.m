function [ status ] = mlcLaunchToast(MLCapp, msg, duration)
% Launch a toast = message to be displayed
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% msg ........ Message to display on Android device
% duration ... Message display duration in ms
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.launchToast(msg,duration);
end