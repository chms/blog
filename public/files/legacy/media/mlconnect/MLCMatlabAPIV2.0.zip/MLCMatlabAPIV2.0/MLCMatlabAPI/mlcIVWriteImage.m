function [ status ] = mlcIVWriteImage(MLCapp, image)
% Send an image to the app.
% Image will only show when ImageView currently open
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% image ...... Can be a file name (jpg or png)
%              or a valid figure number
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    if isscalar(image)
        figure(image);
        drawnow;
        f=getframe(image);
        imo=frame2im(f);
        image=im2java(imo);
    else
        imf=fopen(image,'r');
        image=uint8(fread(imf));
        fclose(imf);
    end

    status = MLCapp.writeImage(1,image);
end

