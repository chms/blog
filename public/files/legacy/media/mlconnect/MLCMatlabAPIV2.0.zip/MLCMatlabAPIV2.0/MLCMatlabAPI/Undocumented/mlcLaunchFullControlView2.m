function [ status ] = mlcLaunchFullControlView2(MLCapp)
% Launch FullControlView2 GUI - note that this GUI will very likely change
% over time, as its main purpose is to enable a direct Matlab session!
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    status = MLCapp.launchView('FullControlView2');
end