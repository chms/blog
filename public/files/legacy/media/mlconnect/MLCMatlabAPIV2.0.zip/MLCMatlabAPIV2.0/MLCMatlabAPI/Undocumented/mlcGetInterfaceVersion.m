function [ version ] = mlcGetInterfaceVersion(MLCapp)
% Retrieve MLC Matlab interface version (always has to be less or equal to
% the app version, will be checked automatically when connecting)
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ... MLCAndroidInterface java object
%--- OUTPUT ---------------------------------------------------------------
% version ... Version of the MLC interface running in Matlab
%--------------------------------------------------------------------------
    version=char(MLCapp.getInterfaceVersion());
end

