function [ MLCapp ] = mlcStartDefaultServer()
% Start an MLC Server with default settings
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- OUTPUT ---------------------------------------------------------------
% MLCapp ....... MLCAndroidInterface Java object for further use
%--------------------------------------------------------------------------
    % Server config
    serverName = ['Matlab ', version('-release')] ;
    port = 21566;                %TCP/IP port
    timeout = 15000;             %Timeout in ms
    bufferSize = 1024*1024;      %Buffer size in bytes
    retry = 0;                   %Server will wait retry x timeout ms
                                 %or forever when retry=0

    % Connecting to Android device
    MLCapp = mlcStartServer(serverName, port, timeout, bufferSize, retry); %Start server
end