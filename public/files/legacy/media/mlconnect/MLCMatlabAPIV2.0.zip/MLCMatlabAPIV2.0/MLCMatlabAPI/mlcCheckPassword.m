function [ passwordOK ] = mlcCheckPassword(MLCapp, cpassword)
% Checks if the password the app provides is equal to the input parameter
% cpassword. Note that the password is not tranmitted in plain text,
% but hashed.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ...... MLCAndroidInterface java object
% cpassword ... The password to check against the app password
%--- OUTPUT ---------------------------------------------------------------
% passwordOK ... true .... when the pwd provided by the app == cpassword
%                false ... otherwise
%--------------------------------------------------------------------------
    passwordOK = MLCapp.checkPassword(cpassword);
end
