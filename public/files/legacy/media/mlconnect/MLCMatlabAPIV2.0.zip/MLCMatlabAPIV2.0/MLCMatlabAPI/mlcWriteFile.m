function [ status ] = mlcWriteFile(MLCapp, data, targetFilename, open)
% Send a file to your Android device and open it with the standard app for
% this filetype if desired.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ........... MLCAndroidInterface java object
% data ............. Can be
%                    - a filename, then the content of the file will be
%                      transmitted.
%                    - an array with data, then the binary data of the
%                      array will be transmitted. Array must be greater
%                      than 1 byte!!
%                    - a handle to a Matlab figure, then the ontent of the
%                      figure will be transmitted as png.
% targetfilename ... Filename on your Android device
% open ............. false ... will just transmit the file to your device
%                    true .... will tell Android to open the file with the 
%                              standard Android app for the given filetype.
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
    if isscalar(data)
        currentFig = get(0,'CurrentFigure');
        figure(data);
        drawnow;
        f = getframe(data);
        imo = frame2im(f);
        bData = im2java(imo);
        figure(currentFig);
    elseif ischar(data)
        file = fopen(data,'r');
        bData = uint8(fread(file));
        fclose(file);
    else
        bData = data;
    end
    
    status = MLCapp.writeFile(targetFilename, bData, open);
end
