% Initializes MLC classes and directories. Needs to be called at least once
% before any other mlc* commands.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 01.06.2012
%--------------------------------------------------------------------------

% If there is an interface manager present destroy it
if (isappdata(0, 'mlcifm'))
    mlcifm = getappdata(0, 'mlcifm');
    mlcifm.destroy();
    rmappdata(0, 'mlcifm');
end

% Clear java definitions, set path and load JARs
clear all;clear classes;clear java;clc;
pathstr = fileparts(mfilename('fullpath'));

addpath([pathstr, filesep, 'MLCMatlabAPI']);
addpath([pathstr, filesep, 'MLCMatlabAPI', filesep, 'Undocumented']);
javaaddpath([pathstr, filesep, 'MLCMatlabAPI', filesep,'MLCServer.jar']);
javaaddpath([pathstr, filesep, 'MLCMatlabAPI', filesep,'netty-3.3.1.jar']);
clear java;

% Create Interface manager
mlcifm = com.chschmid.MLCInterfaceManager.MLCInterfaceManager();
setappdata(0, 'mlcifm', mlcifm);
clear('mlcifm');
