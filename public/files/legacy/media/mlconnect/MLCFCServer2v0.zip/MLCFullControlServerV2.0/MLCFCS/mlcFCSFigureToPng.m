function [ pngData ] = mlcFCSFigureToPng(fig)
% Convert figure to png
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 07.04.2012
%--- INPUT ----------------------------------------------------------------
% fig ... Figure handle
%--- OUTPUT ---------------------------------------------------------------
% pngData ... png byte data for figure(fig)
%--------------------------------------------------------------------------
    figure(fig);
    drawnow;
    
    f = getframe(fig);
    imo = frame2im(f);
    image = im2java(imo);
    
    dummyObserver = java.awt.Label();
    width = image.getWidth(dummyObserver);
    height = image.getHeight(dummyObserver);
    
    
    bImage = java.awt.image.BufferedImage(width, height, java.awt.image.BufferedImage.TYPE_INT_RGB);
    bImage.getGraphics().drawImage(image, 0, 0, dummyObserver);
    	
%     % Write to file
%     out = java.io.FileOutputStream('tx.png');
% 	  javax.imageio.ImageIO.write(bImage, 'png', out);
% 	  out.close();
%     pngData=0;
    
    out = java.io.ByteArrayOutputStream();
    javax.imageio.ImageIO.write(bImage, 'png', out);
    pngData = typecast(out.toByteArray(),'uint8');
end

