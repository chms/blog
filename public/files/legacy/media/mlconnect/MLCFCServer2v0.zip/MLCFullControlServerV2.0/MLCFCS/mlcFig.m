function [ status ] = mlcFig(MLCapp, fig)
% Send and image to the app, will only show when ImageView currently open
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 14.01.2012
%--- INPUT ----------------------------------------------------------------
% MLCapp ..... MLCAndroidInterface java object
% fig   ...... Valid number of figure to transmit
%--- OUTPUT ---------------------------------------------------------------
% status ... Connection / app status
%--------------------------------------------------------------------------
mlcFCVUnlockUserInput(MLCapp);
mlcLaunchImageView(MLCapp);
mlcIVWriteImage(MLCapp,fig);
mlcSetOrientation(MLCapp,'landscape');