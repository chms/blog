function [ mlcfcsFigs ] = mlcFCSinitmlcfcsFigs()
%MLCFCSINITMLCFCSFIGS Summary of this function goes here
%   Detailed explanation goes here

mlcfcsFigs.updateList = [];
mlcfcsFigs.closeList = [];
mlcfcsFigs.figList = [];
mlcfcsFigs.figs = [];

end