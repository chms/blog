% Ends the MLControll FullControl Server Session
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 14.01.2012
%--------------------------------------------------------------------------
mlcfcs.endFlag=1;

