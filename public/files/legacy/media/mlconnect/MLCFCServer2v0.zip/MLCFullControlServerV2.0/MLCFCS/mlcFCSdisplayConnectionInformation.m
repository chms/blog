%--------------------------------------------------------------------------
% Display connection information
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 10.04.2012
%--------------------------------------------------------------------------

% Display connection status
disp(['Connected to: ', mlcGetClientName(mlcfcs.android)]);
mlcfcs.appVersion=mlcGetAppVersion(mlcfcs.android);
disp(['App Version: ', mlcfcs.appVersion]);
mlcfcs.mlcInterfaceVersion = mlcGetInterfaceVersion(mlcfcs.android);
disp(['Interface version:', mlcfcs.appVersion]);
