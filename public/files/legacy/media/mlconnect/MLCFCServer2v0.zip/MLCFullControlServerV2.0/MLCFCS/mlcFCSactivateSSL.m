%--------------------------------------------------------------------------
% Activate SSL if possible
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 09.04.2012
%--------------------------------------------------------------------------

% Activate SSL if possible (not available for free Edition)
if (mlcSSL(mlcfcs.android, true) == 2)
    disp('Your connection is protected via SSL');
else
    disp('The connection is not encrypted when using the free edition');
end