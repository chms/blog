function [mlcfcs] = mlcFCSprocessFigures(mlcfcs)
% Process figures
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 02.06.2012
%--- INPUT ----------------------------------------------------------------
% mlcfcs ... MLC Full Control Server object
%--------------------------------------------------------------------------
    % Process Matlab figures
    mlcfcs.figs = mlcFCSUpdateFigureContent(mlcfcs.figs);

    % Update figures on phone
    for k1 = 1:length(mlcfcs.figs.closeList)
        mlcFCV2ClearFigure(mlcfcs.android, mlcfcs.figs.closeList(k1));
    end

    for k1 = 1:length(mlcfcs.figs.updateList)
        mlcWriteFile(mlcfcs.android, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).data, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).filename, false);
        mlcFCV2EditFigure(mlcfcs.android, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).id, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).filename, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).filename, mlcfcs.figs.figs(mlcfcs.figs.updateList(k1)).title);
    end
end