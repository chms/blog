%--------------------------------------------------------------------------
% Setup App UI for MLC FullControl Server
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 07.04.2012
%--------------------------------------------------------------------------

% Start up user interface
mlcLaunchFullControlView2(mlcfcs.android);
mlcLockBackButton(mlcfcs.android, true);

if (mlcfcs.android.isFreeEdition())
   mlcFCVResult(mlcfcs.android, 'The connection is not encrypted when using the free edition');
else
   mlcFCVResult(mlcfcs.android, 'Your connection is protected via SSL');
end

if (exist('DEBUG', 'var'))
    if (DEBUG == 1)
        x = sin(0.01 * (1:1000));
        mlcFCVCommand(mlcfcs.android, 'plot(x);');
        mlcFCVCommand(mlcfcs.android, 'figure(2);');
        mlcFCVCommand(mlcfcs.android, 'grid on;');
        mlcFCVCommand(mlcfcs.android, 'grid off;');
    end
end