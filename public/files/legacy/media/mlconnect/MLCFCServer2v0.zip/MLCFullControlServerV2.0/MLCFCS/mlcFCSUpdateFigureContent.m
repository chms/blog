function [ mlcfcsFigs] = mlcFCSUpdateFigureContent(mlcfcsFigs)
% Check figure changes
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 09.04.2012
%--- INPUT ----------------------------------------------------------------
% mlcfcsFigs ... Last known state of figures
%--- OUTPUT ---------------------------------------------------------------
% mlcfcsFigs ... Current state of figures + infos what to change
%--------------------------------------------------------------------------

    % Process figures
    drawnow;
    currentFig = get(0,'CurrentFigure');

    openFigureList = findobj('type','figure');
    oldfigList = mlcfcsFigs.figList;
    figs = mlcfcsFigs.figs;
    updateList = [];

    
    % Find out which figs to close
    closeList = setdiff(oldfigList, openFigureList);
    % Find out which figs are there for the first time
    newList = setdiff(openFigureList, oldfigList);

    % Delete the data of closed figures from structure
    k1 = 1;
    while (k1 <= length(figs))
        if any(closeList == figs(k1).id)
            figs(k1) = [];
            k1 = k1-1;
        end
        k1 = k1+1;
    end

    % Add new figures to structure
    for k1 = 1:length(newList)
        figs(end+1).id = newList(k1);
        figs(end).title = [];
        figs(end).thumbnail = [];
        figs(end).data = [];
        figs(end).toggle = 0;
        figs(end).filename = [];
    end

    % Get image data and find out which figures have to be updated
    for k1 = 1:length(openFigureList)
        figID = openFigureList(k1);
        figData = mlcFCSFigureToPng(figID);

        for k2 = 1:length(figs)
            if figs(k2).id == figID
                isequal = false;
                if (length(figData) == length(figs(k2).data))
                    if (all(figs(k2).data == figData))
                        isequal = true;
                    end
                end
                
                if (~isequal)
                    figs(k2).data = figData;
                    figs(k2).thumbnail = figData;
                    figs(k2).title = ['Figure ', num2str(openFigureList(k1))];
                    if (figs(k2).toggle == 0)
                        figs(k2).toggle = 1;
                    else
                        figs(k2).toggle = 0;
                    end
                    figs(k2).filename = ['fig',num2str(figs(k2).id),'-',num2str(figs(k2).toggle),'.png'];
                    updateList = [updateList, k2];
                end
            end
        end
    end
    
    mlcfcsFigs.figList = openFigureList;
    mlcfcsFigs.closeList = closeList;
    mlcfcsFigs.figs = figs;
    mlcfcsFigs.updateList = updateList;
    
    if (~isempty(currentFig))
        figure(currentFig);
    end
    drawnow;
end

