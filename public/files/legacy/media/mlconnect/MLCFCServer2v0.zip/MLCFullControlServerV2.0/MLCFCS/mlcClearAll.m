% Clear all variables but the important ones
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 14.01.2012
%--------------------------------------------------------------------------

mlcfcs.varlist=who;
command='';
for k1=1:length(mlcfcs.varlist)
    if ~strcmp(mlcfcs.varlist{k1},'mlcfcs')
        command=['clear ',mlcfcs.varlist{k1}];
        eval(command);
    end
end

clear ('k1', 'command');