%--------------------------------------------------------------------------
% MLConnect FullControl Server Configuration
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 07.04.2012
%--------------------------------------------------------------------------

% Settings
mlcfcs.serverName = 'MLC FullControl 2.0'; %Information that client will receive
mlcfcs.ssl = 1;                            %Activate SSL for paid version (1 or 0)
mlcfcs.password  = '1234';                 %Password ('' to deactivate password protection)
mlcfcs.port = 21566;                       %TCP/IP port
mlcfcs.timeout = 10000;                    %Timeout in ms
mlcfcs.retry = 0;                          %Server will wait retry x timeout ms
                                           %or forever when retry=0

% Legacy options
mlcfcs.bufferSize = 1024*1024;             %Buffer size in bytes