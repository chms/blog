%--------------------------------------------------------------------------
% Initialize MLConnect FullControl Server
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 10.04.2012
%--------------------------------------------------------------------------

% Init FullControlServer
clear mlcfcs;
mlcFCSconfig; %Load configuration (port settings ...)

% Display server start message
clc;
disp('-----------------------------------------------------');
disp('MLConnect FullControl Server V2.0');
disp(['Please connect to computer at port ',num2str(mlcfcs.port)]);
disp(['Password: ', mlcfcs.password]);
disp('Waiting for Android device to connect');
disp('Stop server using Ctrl-C');
disp('-----------------------------------------------------');