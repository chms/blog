%--------------------------------------------------------------------------
% Process user input
%--------------------------------------------------------------------------
% (c) Christian M. Schmid
% Last edit: 09.04.2012
%--------------------------------------------------------------------------

% Check connection status
if (~mlcIsStillThere(mlcfcs.android))
    mlcfcs.endFlag=1;
end

% If userInput is available do something
if (~isempty(mlcfcs.userInput))
    disp(mlcfcs.userInput);

    mlcFCVCommand(mlcfcs.android, mlcfcs.userInput);

    mlcfcs.userInput = regexprep(mlcfcs.userInput, 'mlcFig(', 'mlcFig(mlcfcs.android, ');

    clear mlcfcserror;
    mlcfcstemp.result='';

    % Save copy of main object (in case it gets lost
    % (e.g. clear all)
    setappdata(0, 'mlcfcs', mlcfcs);

    try
        mlcfcstemp.result = evalc(mlcfcs.userInput);
        drawnow;
    catch mlcfcserror
        disp(['Error: ',mlcfcserror.message]);
        mlcFCVError(mlcfcs.android,['Error: ',mlcfcserror.message]);
    end

    % Check if user command deleted mlcfcs structure
    % If the required objects got deleted (e.g. clear all
    % was executed) get them again
    if (~exist('mlcfcs', 'var'))
        if(isappdata(0, 'mlcfcs') == 0)
          msg=['Severe FullControl Server Error!', char(10), ...
          'No mlcfcs object found'];
          error(msg);
        else
            mlcfcs = getappdata(0, 'mlcfcs');
        end
    end
    
    % Process result and send to Android device
    mlcfcs.result = mlcfcstemp.result;
    clear('mlcfcstemp');
    
    if (~isempty(mlcfcs.result))
        % Reformat result
        mlcfcs.result = regexprep(mlcfcs.result,[char(10),char(10)],char(10));
        mlcfcs.result = strtrim(mlcfcs.result);
        mlcFCVResult(mlcfcs.android, mlcfcs.result);
    end
    mlcFCVUnlockUserInput(mlcfcs.android);

    % Check status
    if (mlcfcs.android.getStatus == 0)
        mlcfcs.endFlag=1;
    end
end