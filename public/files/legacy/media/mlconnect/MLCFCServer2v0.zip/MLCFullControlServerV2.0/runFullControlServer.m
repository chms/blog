%--------------------------------------------------------------------------
% MLConnect FullControl Server 2.0
% Let's you connect your MLConnect app to Matlab on ends
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--------------------------------------------------------------------------

close all;
pathstr = fileparts(mfilename('fullpath'));
addpath([pathstr , filesep, 'MLCFCS']);
opengl software;

% Init MLC
mlcInitMLC();

% For debugging
% DEBUG = 1;

% Run server, forever and ever and ever (end with Ctrl-C from Matlab)
while(true)
    mlcFCSinit();
    
    % Wait for connection
    try 
        mlcfcs.android = mlcStartServer(mlcfcs.serverName, mlcfcs.port, mlcfcs.timeout, mlcfcs.bufferSize, mlcfcs.retry); %Start server
    catch mlcfcserror
        disp(['Error: ', mlcfcserror.message]);
        clear('mlcfcs');
        pause(2);
    end
    clear('mlcfcserror');
    
    % Check if connection was successful
    if exist('mlcfcs', 'var')
        if (mlcIsConnected(mlcfcs.android))
            
            mlcFCSdisplayConnectionInformation();
            mlcFCSactivateSSL();

            % Check password
            if (mlcCheckPassword(mlcfcs.android, mlcfcs.password)  == true)
                
                mlcFCSsetupAppUI();
                
                % Process input / main loop
                mlcfcs.figs = mlcFCSinitmlcfcsFigs();
                mlcfcs.endFlag = 0;
                while(mlcfcs.endFlag == 0)
                    % Get user input
                    mlcfcs = mlcFCSprocessFigures(mlcfcs);
                    mlcfcs.userInput = mlcFCVWaitForInput(mlcfcs.android,1);
                    mlcFCSprocessUserInput();
                end
                
            else
                disp('Password check failed!');
                pause(1);
            end
            
            % Close session
            mlcClose(mlcfcs.android);
        end
    end
end