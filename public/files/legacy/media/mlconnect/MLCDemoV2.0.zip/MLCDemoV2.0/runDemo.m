% MLConnect Guided Demo Code for MLConnect V2.0
% Matlab and the App will both explain what's happening
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2012
%--------------------------------------------------------------------------
%% Init classes and settings
mlcInitMLC();

opengl software;

% Config server
serverName = ['Matlab ', version('-release')];
port       = 21566;        % TCP/IP to use Port
timeout    = 1000;         % Timeout in ms
bufferSize = 1024*1024;    % Buffer size in bytes
retry      = 180;          % Server will wait retry x timeout ms
                           % or forever when retry=0

%% Connecting to Android device
dispDemo('hello', port);
android = mlcStartServer(serverName, port, timeout, bufferSize, retry); %Start server
pause(0.5);

%% If device is connected, test all function available
if (mlcIsConnected(android))
    disp(['Connected to: ', mlcGetClientName(android)]);
    
    %Get version of app and matlab interface
    appVersion = mlcGetAppVersion(android);                %Please not: mlcGetAppVersion is an undocumented function
    disp(['App Version: ', appVersion]);
    mlcInterfaceVersion = mlcGetInterfaceVersion(android); %Please note: mlcGetInterfaceVersion is an undocumented function
    disp(['Interface version:', mlcInterfaceVersion]);
    dispDemo('testing', '-');
    pause(3);
    
    %Show a message
    mlcLaunchToast(android, 'Hello World!', 300);
    msg = [' 1. ', mlcGetClientName(android), ' will now display a toast (=message).'];
    disp(msg);
    pause(3);
    
    %Enable SSL/TLS encyrption - enabling and disabling is possible anytime
    msg = ' 2. Trying to activate SSL/TLS encryption';
    disp(msg); mlcLaunchToast(android, msg, 300);
    result = mlcSSL(android, true);
    if (result == 2)
        msg = '    SSL/TLS was activated sucessfully, your connection is now encrypted.';
    else
        msg = '    SSL/TLS encryption is not available in the free edition.';
    end
    pause(3);
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Play an audio alert
    mlcLaunchAudio(android);
    msg = [' 3. ', mlcGetClientName(android), ' plays an audio alert.'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Check if the user password is equal to a given string
    msg = '''demo''.';
    if (mlcCheckPassword(android, 'demo')  == false)
        msg = ['not ', msg];
    end
    msg = [' 4. The password provided by ', mlcGetClientName(android),' was ', msg];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Lock screen dimming
    mlcLockScreenDimming(android,true);
    msg = [' 5. ', mlcGetClientName(android), ' locks the screen dimming function'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Launch ImageView
    mlcLaunchImageView(android);
    msg = [' 6. ', mlcGetClientName(android), ' goes into ImagView mode'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Transmit image from file (jpg or png)
    mlcIVWriteImage(android, 'Hawaii1.jpg');
    msg = [' 7. ', mlcGetClientName(android), ' displays an image from a file'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Transmit image from plot
    logo(); fig=gcf;
    mlcIVWriteImage(android, fig);
    msg = [' 8. ', mlcGetClientName(android), ' displays an image from a plot'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Lock Back button
    mlcLockBackButton(android, true);
    msg=[' 9. ', mlcGetClientName(android), ' back button locked'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Unlock Back button
    mlcLockBackButton(android, false);
    msg=['10. ', mlcGetClientName(android), ' back button unlocked'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Orientation: horizontal
    mlcSetOrientation(android, 'landscape');
    msg = ['11. ', mlcGetClientName(android), ' orientation set to landscape'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Orientation: vertical
    mlcSetOrientation(android, 'portrait');
    msg = ['12. ', mlcGetClientName(android), ' orientation set to portrait'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Orientation: vertical
    mlcSetOrientation(android, 'auto');
    msg = ['13. ', mlcGetClientName(android), ' orientation set to auto'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Launch FullControlView
    mlcLaunchFullControlView(android);
    msg = ['14. ', mlcGetClientName(android), ' will go into FullControl mode'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Post on FullControlView
    mlcFCVCommand(android, 'This is a command');
    mlcFCVResult(android, 'This is a result');
    mlcFCVError(android, 'This is an error');
    msg = ['15. ', mlcGetClientName(android), ' will post something on FullControlView'];
    disp(msg); %mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Transmit a file and display it with the standard app on Android device
    msg = ['16. ', mlcGetClientName(android), ' will now receive a file and open it with the standard app for that filetype'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    mlcWriteFile(android, 'tour.png', 'tour.png', true);
    mlcFCVCommand(android, 'Please enter text below and press enter');
    pause(3);
    
    %Get command from FullControl view
    msg = '17. Please go now back to the MLConnect app and enter some text.';
    disp(msg); mlcLaunchToast(android, msg, 300);
    
    userInput = mlcFCVWaitForInput(android,0);
    mlcFCVUnlockUserInput(android);
    msg = ['    You said: ',userInput];
    mlcFCVResult(android, msg);
    disp(msg);
    pause(3);
    
    %Launch SensorView
    mlcLaunchSensorView(android);
    mlcLockBackButton(android, true);
    msg=['18. ', mlcGetClientName(android), ' will go into SensorView mode'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Get info for all sensors
    msg = ['19. ', mlcGetClientName(android), ' will check all sensors on board'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    type = 'accelerometer';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type ='orientation';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'gyroscope';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'proximity';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'light';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'magneticfield';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'pressure';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    type = 'temperature';
    info = mlcSensorGetInfo(android,type);
    disp(['    ',type, ': ', info]);
    pause(3);
    
    %Read a sensor value
    msg = '20. Let''s try and read some sensor values';
    disp(msg); mlcLaunchToast(android, msg, 300);
    try
        acceleration = mlcSensorRead(android, 'accelerometer');
        acceleration %#ok
    catch err
        disp(['Sorry, looks like', mlcGetClientName(android),'doesn''t have an accelerometer']);
    end
    
    try
        light = mlcSensorRead(android, 'light');
        light %#ok
    catch err
        disp(['Sorry, looks like', mlcGetClientName(android),'doesn''t have a light sensor']);
    end
    pause(3);
    
    %Sensor streaming mode
    msg = '21. If you''d like to get sensor data faster or more than once, activate sensor streaming';
    disp(msg); mlcLaunchToast(android, msg, 300);
    try
        mlcSetOrientation(android, 'portrait');
        mlcSensorStreaming(android, 'accelerometer', 3);
        figure(1);
        N = 200;
        acd = zeros(3,N);
        for k1 = 1:N
            acd(:,k1) = mlcSensorRead(android, 'accelerometer');
            plot(acd.'); ylim([-12,12]); grid on;
            drawnow;
        end
        mlcSetOrientation(android, 'auto');
        mlcSensorStreaming(android, 'accelerometer', 0);
    catch err
        disp(['Sorry, looks like', mlcGetClientName(android),'doesn''t have an accelerometer']);
    end
    
    %Close current view
    mlcCloseView(android);
    msg = ['22. ', mlcGetClientName(android), ' closed current view'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
    
    %Check if device is still there
    stillThere = mlcIsStillThere(android);
    msg = ['23. Checking if ', mlcGetClientName(android), ' is still connected'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    if (stillThere)
        disp('    Device still there');
    end
    pause(3);
    
    %Unlock screen dimming
    mlcLockScreenDimming(android,false);
    msg=['24. ', mlcGetClientName(android), ' released the screen dimming lock'];
    disp(msg); mlcLaunchToast(android, msg, 300);
    pause(3);
     
    %Close connection
    msg = '25. Connection closed';
    disp(msg); mlcLaunchToast(android, msg, 300);
    mlcClose(android);
    
else
    disp('No device tried to connect');
end




