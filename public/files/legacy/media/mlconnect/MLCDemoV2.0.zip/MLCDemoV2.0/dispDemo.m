function dispDemo(text,plus)
    if (strcmp(text,'hello'))
        disp('-----------------------------------------------------');
        disp('MLConnect V2.0 Demo');
        disp(['Please connect to computer at port ',num2str(plus)]);
        disp('Waiting for Android device to connect');
        disp('Quit using Ctrl-C');
        disp('-----------------------------------------------------');
    end
    
    if (strcmp(text,'accelerometer'))
        disp('-----------------------------------------------------');
        disp('MLConnect Accelerometer V2.0');
        disp('Please connect to computer at port 21566');
        disp('Waiting for Android device to connect');
        disp('Quit using Ctrl-C');
        disp('-----------------------------------------------------');
    end

    if (strcmp(text,'testing'))
        disp('-----------------------------------------------------');
        disp('Will now continue to test all functions:');
    end
end

