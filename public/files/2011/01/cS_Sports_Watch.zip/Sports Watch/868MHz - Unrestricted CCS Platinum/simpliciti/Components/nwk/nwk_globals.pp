# FIXED
simpliciti/Components/nwk/nwk_globals.obj: ../simpliciti/Components/nwk/nwk_globals.c
simpliciti/Components/nwk/nwk_globals.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/string.h
simpliciti/Components/nwk/nwk_globals.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/linkage.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/bsp.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_board_defs.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/mcus/bsp_msp430_defs.h
simpliciti/Components/nwk/nwk_globals.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
simpliciti/Components/nwk/nwk_globals.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
simpliciti/Components/nwk/nwk_globals.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/intrinsics.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_config.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/bsp_macros.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/mrfi/mrfi.h
simpliciti/Components/nwk/nwk_globals.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/mrfi/mrfi_defs.h
simpliciti/Components/nwk/nwk_globals.obj: ../simpliciti/Components/nwk/nwk_types.h
simpliciti/Components/nwk/nwk_globals.obj: ../simpliciti/Components/nwk/nwk_globals.h
