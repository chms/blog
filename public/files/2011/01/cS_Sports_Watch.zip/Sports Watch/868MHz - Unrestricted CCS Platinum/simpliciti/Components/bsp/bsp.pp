# FIXED
simpliciti/Components/bsp/bsp.obj: ../simpliciti/Components/bsp/bsp.c
simpliciti/Components/bsp/bsp.obj: ../simpliciti/Components/bsp/bsp.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_board_defs.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/mcus/bsp_msp430_defs.h
simpliciti/Components/bsp/bsp.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
simpliciti/Components/bsp/bsp.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
simpliciti/Components/bsp/bsp.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/intrinsics.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_config.h
simpliciti/Components/bsp/bsp.obj: ../simpliciti/Components/bsp/bsp_macros.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_driver_defs.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_board.c
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_drivers.c
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/bsp_leds.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_led_defs.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/code/bsp_generic_leds.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/bsp_buttons.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_button_defs.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/code/bsp_generic_buttons.h
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/code/bsp_leds.c
simpliciti/Components/bsp/bsp.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/Components/bsp/drivers/code/bsp_buttons.c
