# FIXED
logic/user.obj: ../logic/user.c
logic/user.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/user.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/user.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/user.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/user.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/user.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/user.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/user.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/user.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/buzzer.h
logic/user.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/user.obj: ../logic/menu.h
logic/user.obj: ../logic/date.h
logic/user.obj: ../logic/clock.h
logic/user.obj: ../logic/user.h
logic/user.obj: ../logic/stopwatch.h
