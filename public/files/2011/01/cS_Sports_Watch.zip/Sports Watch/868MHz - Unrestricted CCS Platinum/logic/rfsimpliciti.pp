# FIXED
logic/rfsimpliciti.obj: ../logic/rfsimpliciti.c
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/rfsimpliciti.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/rfsimpliciti.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/rfsimpliciti.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/rfsimpliciti.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/rfsimpliciti.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/vti_as.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/timer.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/radio.h
logic/rfsimpliciti.obj: ../logic/acceleration.h
logic/rfsimpliciti.obj: ../logic/rfsimpliciti.h
logic/rfsimpliciti.obj: ../logic/bluerobin.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/simpliciti.h
logic/rfsimpliciti.obj: ../logic/clock.h
logic/rfsimpliciti.obj: ../logic/date.h
logic/rfsimpliciti.obj: ../logic/alarm.h
logic/rfsimpliciti.obj: ../logic/temperature.h
logic/rfsimpliciti.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/vti_ps.h
logic/rfsimpliciti.obj: ../logic/altitude.h
