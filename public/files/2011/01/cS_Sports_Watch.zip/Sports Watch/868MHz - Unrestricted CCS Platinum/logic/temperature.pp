# FIXED
logic/temperature.obj: ../logic/temperature.c
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/temperature.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/temperature.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/temperature.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/temperature.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/temperature.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/temperature.obj: ../logic/temperature.h
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/adc12.h
logic/temperature.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/timer.h
logic/temperature.obj: ../logic/user.h
