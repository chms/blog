# FIXED
logic/cSLight.obj: ../logic/cSLight.c
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/string.h
logic/cSLight.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/linkage.h
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/timer.h
logic/cSLight.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/rf1a.h
logic/cSLight.obj: ../logic/menu.h
logic/cSLight.obj: ../logic/cSLight.h
