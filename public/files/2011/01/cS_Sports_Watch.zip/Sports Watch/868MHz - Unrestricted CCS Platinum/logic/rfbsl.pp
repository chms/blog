# FIXED
logic/rfbsl.obj: ../logic/rfbsl.c
logic/rfbsl.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/rfbsl.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/rfbsl.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/rfbsl.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/rfbsl.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/rfbsl.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/rfbsl.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/rfbsl.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/rfbsl.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/rfbsl.obj: ../logic/rfbsl.h
logic/rfbsl.obj: ../logic/bluerobin.h
logic/rfbsl.obj: ../logic/rfsimpliciti.h
