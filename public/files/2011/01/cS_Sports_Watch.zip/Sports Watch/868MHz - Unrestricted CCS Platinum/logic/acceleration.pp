# FIXED
logic/acceleration.obj: ../logic/acceleration.c
logic/acceleration.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/acceleration.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/acceleration.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/acceleration.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/acceleration.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/acceleration.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/acceleration.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/acceleration.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/acceleration.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/vti_as.h
logic/acceleration.obj: ../logic/acceleration.h
logic/acceleration.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/simpliciti.h
logic/acceleration.obj: ../logic/user.h
