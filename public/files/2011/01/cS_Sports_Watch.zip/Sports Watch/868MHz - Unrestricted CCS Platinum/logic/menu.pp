# FIXED
logic/menu.obj: ../logic/menu.c
logic/menu.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/menu.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/menu.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/menu.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/menu.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/menu.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/menu.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/menu.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/menu.obj: ../logic/menu.h
logic/menu.obj: ../logic/user.h
logic/menu.obj: ../logic/clock.h
logic/menu.obj: ../logic/date.h
logic/menu.obj: ../logic/alarm.h
logic/menu.obj: ../logic/stopwatch.h
logic/menu.obj: ../logic/temperature.h
logic/menu.obj: ../logic/altitude.h
logic/menu.obj: ../logic/battery.h
logic/menu.obj: ../logic/bluerobin.h
logic/menu.obj: ../logic/rfsimpliciti.h
logic/menu.obj: ../logic/acceleration.h
logic/menu.obj: ../logic/rfbsl.h
