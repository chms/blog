# FIXED
logic/alarm.obj: ../logic/alarm.c
logic/alarm.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/alarm.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/alarm.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/alarm.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/alarm.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/alarm.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/alarm.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/alarm.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/alarm.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/buzzer.h
logic/alarm.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/alarm.obj: ../logic/alarm.h
logic/alarm.obj: ../logic/clock.h
logic/alarm.obj: ../logic/user.h
