# FIXED
logic/date.obj: ../logic/date.c
logic/date.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/date.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/date.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/date.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/date.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/date.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/date.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/date.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/date.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/date.obj: ../logic/date.h
logic/date.obj: ../logic/user.h
logic/date.obj: ../logic/cSLight.h
