# FIXED
logic/stopwatch.obj: ../logic/stopwatch.c
logic/stopwatch.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
logic/stopwatch.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/string.h
logic/stopwatch.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/linkage.h
logic/stopwatch.obj: ../logic/stopwatch.h
logic/stopwatch.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/ports.h
logic/stopwatch.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/display.h
logic/stopwatch.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/driver/timer.h
logic/stopwatch.obj: ../logic/menu.h
