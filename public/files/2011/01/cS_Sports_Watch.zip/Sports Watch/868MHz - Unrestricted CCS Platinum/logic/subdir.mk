################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../logic/acceleration.c \
../logic/alarm.c \
../logic/altitude.c \
../logic/battery.c \
../logic/bluerobin.c \
../logic/cSLight.c \
../logic/clock.c \
../logic/date.c \
../logic/menu.c \
../logic/rfbsl.c \
../logic/rfsimpliciti.c \
../logic/stopwatch.c \
../logic/temperature.c \
../logic/test.c \
../logic/user.c 

OBJS += \
./logic/acceleration.obj \
./logic/alarm.obj \
./logic/altitude.obj \
./logic/battery.obj \
./logic/bluerobin.obj \
./logic/cSLight.obj \
./logic/clock.obj \
./logic/date.obj \
./logic/menu.obj \
./logic/rfbsl.obj \
./logic/rfsimpliciti.obj \
./logic/stopwatch.obj \
./logic/temperature.obj \
./logic/test.obj \
./logic/user.obj 

C_DEPS += \
./logic/acceleration.pp \
./logic/alarm.pp \
./logic/altitude.pp \
./logic/battery.pp \
./logic/bluerobin.pp \
./logic/cSLight.pp \
./logic/clock.pp \
./logic/date.pp \
./logic/menu.pp \
./logic/rfbsl.pp \
./logic/rfsimpliciti.pp \
./logic/stopwatch.pp \
./logic/temperature.pp \
./logic/test.pp \
./logic/user.pp 

OBJS__QTD += \
".\logic\acceleration.obj" \
".\logic\alarm.obj" \
".\logic\altitude.obj" \
".\logic\battery.obj" \
".\logic\bluerobin.obj" \
".\logic\cSLight.obj" \
".\logic\clock.obj" \
".\logic\date.obj" \
".\logic\menu.obj" \
".\logic\rfbsl.obj" \
".\logic\rfsimpliciti.obj" \
".\logic\stopwatch.obj" \
".\logic\temperature.obj" \
".\logic\test.obj" \
".\logic\user.obj" 

C_DEPS__QTD += \
".\logic\acceleration.pp" \
".\logic\alarm.pp" \
".\logic\altitude.pp" \
".\logic\battery.pp" \
".\logic\bluerobin.pp" \
".\logic\cSLight.pp" \
".\logic\clock.pp" \
".\logic\date.pp" \
".\logic\menu.pp" \
".\logic\rfbsl.pp" \
".\logic\rfsimpliciti.pp" \
".\logic\stopwatch.pp" \
".\logic\temperature.pp" \
".\logic\test.pp" \
".\logic\user.pp" 

C_SRCS_QUOTED += \
"../logic/acceleration.c" \
"../logic/alarm.c" \
"../logic/altitude.c" \
"../logic/battery.c" \
"../logic/bluerobin.c" \
"../logic/cSLight.c" \
"../logic/clock.c" \
"../logic/date.c" \
"../logic/menu.c" \
"../logic/rfbsl.c" \
"../logic/rfsimpliciti.c" \
"../logic/stopwatch.c" \
"../logic/temperature.c" \
"../logic/test.c" \
"../logic/user.c" 


# Each subdirectory must supply rules for building sources it contributes
logic/acceleration.obj: ../logic/acceleration.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/acceleration.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/alarm.obj: ../logic/alarm.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/alarm.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/altitude.obj: ../logic/altitude.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/altitude.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/battery.obj: ../logic/battery.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/battery.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/bluerobin.obj: ../logic/bluerobin.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/bluerobin.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/cSLight.obj: ../logic/cSLight.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/cSLight.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/clock.obj: ../logic/clock.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/clock.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/date.obj: ../logic/date.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/date.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/menu.obj: ../logic/menu.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/menu.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/rfbsl.obj: ../logic/rfbsl.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/rfbsl.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/rfsimpliciti.obj: ../logic/rfsimpliciti.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/rfsimpliciti.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/stopwatch.obj: ../logic/stopwatch.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/stopwatch.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/temperature.obj: ../logic/temperature.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/temperature.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/test.obj: ../logic/test.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/test.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

logic/user.obj: ../logic/user.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="logic/user.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="logic" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '


