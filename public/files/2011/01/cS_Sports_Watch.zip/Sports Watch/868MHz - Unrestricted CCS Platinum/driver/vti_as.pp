# FIXED
driver/vti_as.obj: ../driver/vti_as.c
driver/vti_as.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/include/project.h
driver/vti_as.obj: C:/Texas\ Instruments/ccsv4/msp430/include/cc430x613x.h
driver/vti_as.obj: C:/Texas\ Instruments/ccsv4/msp430/include/in430.h
driver/vti_as.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/bluerobin/bm.h
driver/vti_as.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/stddef.h
driver/vti_as.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/limits.h
driver/vti_as.obj: C:/Texas\ Instruments/ccsv4/tools/compiler/msp430/include/float.h
driver/vti_as.obj: D:/Christian\ M.\ Schmid/My\ Dropbox/Texas\ Instruments/Chronos\ Watch\ cSLight/CCS/Sports\ Watch/simpliciti/simpliciti.h
driver/vti_as.obj: ../driver/vti_as.h
driver/vti_as.obj: ../driver/timer.h
driver/vti_as.obj: ../driver/display.h
