################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../driver/adc12.c \
../driver/buzzer.c \
../driver/display.c \
../driver/display1.c \
../driver/pmm.c \
../driver/ports.c \
../driver/radio.c \
../driver/rf1a.c \
../driver/timer.c \
../driver/vti_as.c \
../driver/vti_ps.c 

OBJS += \
./driver/adc12.obj \
./driver/buzzer.obj \
./driver/display.obj \
./driver/display1.obj \
./driver/pmm.obj \
./driver/ports.obj \
./driver/radio.obj \
./driver/rf1a.obj \
./driver/timer.obj \
./driver/vti_as.obj \
./driver/vti_ps.obj 

C_DEPS += \
./driver/adc12.pp \
./driver/buzzer.pp \
./driver/display.pp \
./driver/display1.pp \
./driver/pmm.pp \
./driver/ports.pp \
./driver/radio.pp \
./driver/rf1a.pp \
./driver/timer.pp \
./driver/vti_as.pp \
./driver/vti_ps.pp 

OBJS__QTD += \
".\driver\adc12.obj" \
".\driver\buzzer.obj" \
".\driver\display.obj" \
".\driver\display1.obj" \
".\driver\pmm.obj" \
".\driver\ports.obj" \
".\driver\radio.obj" \
".\driver\rf1a.obj" \
".\driver\timer.obj" \
".\driver\vti_as.obj" \
".\driver\vti_ps.obj" 

C_DEPS__QTD += \
".\driver\adc12.pp" \
".\driver\buzzer.pp" \
".\driver\display.pp" \
".\driver\display1.pp" \
".\driver\pmm.pp" \
".\driver\ports.pp" \
".\driver\radio.pp" \
".\driver\rf1a.pp" \
".\driver\timer.pp" \
".\driver\vti_as.pp" \
".\driver\vti_ps.pp" 

C_SRCS_QUOTED += \
"../driver/adc12.c" \
"../driver/buzzer.c" \
"../driver/display.c" \
"../driver/display1.c" \
"../driver/pmm.c" \
"../driver/ports.c" \
"../driver/radio.c" \
"../driver/rf1a.c" \
"../driver/timer.c" \
"../driver/vti_as.c" \
"../driver/vti_ps.c" 


# Each subdirectory must supply rules for building sources it contributes
driver/adc12.obj: ../driver/adc12.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/adc12.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/buzzer.obj: ../driver/buzzer.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/buzzer.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/display.obj: ../driver/display.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/display.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/display1.obj: ../driver/display1.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/display1.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/pmm.obj: ../driver/pmm.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/pmm.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/ports.obj: ../driver/ports.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/ports.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/radio.obj: ../driver/radio.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/radio.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/rf1a.obj: ../driver/rf1a.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/rf1a.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/timer.obj: ../driver/timer.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/timer.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/vti_as.obj: ../driver/vti_as.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/vti_as.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '

driver/vti_ps.obj: ../driver/vti_ps.c $(GEN_OPTS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	$(shell echo --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\smpl_nwk_config.dat" --cmd_file="D:\Christian M. Schmid\My Dropbox\Texas Instruments\Chronos Watch cSLight\CCS\Sports Watch\simpliciti\Applications\configuration\End Device\smpl_config.dat" > ccsCompiler.opt)
	$(shell echo --silicon_version=mspx >> ccsCompiler.opt)
	$(shell echo -g >> ccsCompiler.opt)
	$(shell echo -O3 >> ccsCompiler.opt)
	$(shell echo --define=__CCE__ --define=ISM_EU --define=__CC430F6137__ --define=MRFI_CC430 >> ccsCompiler.opt)
	$(shell echo --include_path="C:/Texas Instruments/ccsv4/msp430/include" --include_path="C:/Texas Instruments/ccsv4/tools/compiler/msp430/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/include" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/driver" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/logic" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/bluerobin" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Applications/application/End Device" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/boards/CC430EM/bsp_external" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/drivers/code" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/bsp/mcus" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/radios/family5" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/mrfi/smartrf" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk" --include_path="D:/Christian M. Schmid/My Dropbox/Texas Instruments/Chronos Watch cSLight/CCS/Sports Watch/simpliciti/Components/nwk_applications" >> ccsCompiler.opt)
	$(shell echo --diag_warning=225 >> ccsCompiler.opt)
	$(shell echo --call_assumptions=0 >> ccsCompiler.opt)
	$(shell echo --gen_opt_info=2 >> ccsCompiler.opt)
	$(shell echo --printf_support=minimal >> ccsCompiler.opt)
	$(shell echo --preproc_with_compile >> ccsCompiler.opt)
	$(shell echo --preproc_dependency="driver/vti_ps.pp" >> ccsCompiler.opt)
	$(shell echo --obj_directory="driver" >> ccsCompiler.opt)
	$(if $(strip $(GEN_OPTS_QUOTED)), $(shell echo $(GEN_OPTS_QUOTED) >> ccsCompiler.opt))
	$(if $(strip $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")), $(shell echo $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#") >> ccsCompiler.opt))
	"C:/Texas Instruments/ccsv4/tools/compiler/msp430/bin/cl430" -@ccsCompiler.opt
	@echo 'Finished building: $<'
	@echo ' '


