// *************************************************************************************************
// cSLight
// Extension to drive the Conrad "Funk-Lichtschalter-mit-Sender"
// http://www.conrad.at/ce/de/product/620587/Funk-Lichtschalter-mit-Sender
// (c) Christian M. Schmid
// 1.1.2011
// *************************************************************************************************


// *************************************************************************************************
// Include section

// system
#include "project.h"
#include <string.h>

// driver
#include "ports.h"
#include "display.h"
#include "timer.h"
#include "rf1a.h"

// logic
#include "menu.h"
#include "cSLight.h"


// *************************************************************************************************
// Prototypes section
void cSL_transmit_code(void);
void sx_cSLight(u8 line);
//extern void mx_cSLight(u8 line);
void display_cSLight(u8 line, u8 update);
void InitRadio(void);
void WriteBurstPATable(unsigned char *buffer, unsigned char count);
void WriteRfSettings(RF_SETTINGS *pRfSettings);

// *************************************************************************************************
// Global Variable section
volatile u8 cSLightConfig;

// *************************************************************************************************
// Define section
#define st(x)      					do { x } while (__LINE__ == -1)
#define ENTER_CRITICAL_SECTION(x)  	st( x = __get_interrupt_state(); __disable_interrupt(); )
#define EXIT_CRITICAL_SECTION(x)    __set_interrupt_state(x)

unsigned char cSLpaTable[2]={0x00,0xC3}; //0 dBm
unsigned char cSLcommandBedLight[CSLCOMMANDLENGTH]={0x25, 0xB2, 0x5B, 0x24, 0x92};
unsigned char cSLcommandMainLight[CSLCOMMANDLENGTH]={0x2C, 0xB6, 0xC9, 0x64, 0x92};
//unsigned char cSLcommandMainLight[CSLCOMMANDLENGTH]={0x2C, 0x96, 0xD9, 0x64, 0x92};
// Deviation = 47.607422 
// Base frequency = 868.349854 
// Carrier frequency = 868.349854 
// Channel number = 0 
// Carrier frequency = 868.349854 
// Modulation format = ASK/OOK 
// Manchester enable = false 
// Sync word qualifier mode = No preamble/sync 
// Preamble count = 4 
// Channel spacing = 199.951172 
// Carrier frequency = 868.349854 
// Data rate = 1.59931 
// RX filter BW = 203.125000 
// Data format = Normal mode 
// Length config = Fixed packet length mode. Length configured in PKTLEN register 
// CRC enable = false 
// Packet length = 50 
// Device address = 0 
// Address config = No address check 
// CRC autoflush = false 
// PA ramping = false 
// TX power = 0 
RF_SETTINGS cSLrfSettings = {
    0x29,  // IOCFG2           GDO2 Output Configuration
    0x2E,  // IOCFG1           GDO1 Output Configuration
    0x2E,  // IOCFG0           GDO0 Output Configuration
    0x07,  // FIFOTHR          RX FIFO and TX FIFO Thresholds
    0xD3,  // SYNC1            Sync Word, High Byte
    0x91,  // SYNC0            Sync Word, Low Byte
    0x05,  // PKTLEN           Packet Length
    0x04,  // PKTCTRL1         Packet Automation Control
    0x00,  // PKTCTRL0         Packet Automation Control
    0x00,  // ADDR             Device Address
    0x00,  // CHANNR           Channel Number
    0x0F,  // FSCTRL1          Frequency Synthesizer Control
    0x00,  // FSCTRL0          Frequency Synthesizer Control
    0x21,  // FREQ2            Frequency Control Word, High Byte
    0x65,  // FREQ1            Frequency Control Word, Middle Byte
    0xE8,  // FREQ0            Frequency Control Word, Low Byte
    0x86,  // MDMCFG4          Modem Configuration
    0x02,  // MDMCFG3          Modem Configuration
    0x30,  // MDMCFG2          Modem Configuration
    0x22,  // MDMCFG1          Modem Configuration
    0xF8,  // MDMCFG0          Modem Configuration
    0x47,  // DEVIATN          Modem Deviation Setting
    0x07,  // MCSM2            Main Radio Control State Machine Configuration
    0x30,  // MCSM1            Main Radio Control State Machine Configuration
    0x10,  // MCSM0            Main Radio Control State Machine Configuration
    0x76,  // FOCCFG           Frequency Offset Compensation Configuration
    0x6C,  // BSCFG            Bit Synchronization Configuration
    0x03,  // AGCCTRL2         AGC Control
    0x40,  // AGCCTRL1         AGC Control
    0x91,  // AGCCTRL0         AGC Control
    0x87,  // WOREVT1          High Byte Event0 Timeout
    0x6B,  // WOREVT0          Low Byte Event0 Timeout
    0xF8,  // WORCTRL          Wake On Radio Control
    0x56,  // FREND1           Front End RX Configuration
    0x11,  // FREND0           Front End TX Configuration
    0xE9,  // FSCAL3           Frequency Synthesizer Calibration
    0x2A,  // FSCAL2           Frequency Synthesizer Calibration
    0x00,  // FSCAL1           Frequency Synthesizer Calibration
    0x1F,  // FSCAL0           Frequency Synthesizer Calibration
    0x59,  // FSTEST           Frequency Synthesizer Calibration Control
    0x7F,  // PTEST            Production Test
    0x3F,  // AGCTEST          AGC Test
//    0x88,  // TEST2            Various Test Settings
//    0x31,  // TEST1            Various Test Settings
//    0x09,  // TEST0            Various Test Settings
    0x00,  // PARTNUM          Chip ID
    0x06,  // VERSION          Chip ID
    0x00,  // FREQEST          Frequency Offset Estimate From Demodulator
    0xFF,  // LQI              Demodulator Estimate for Link Quality
    0x80,  // RSSI             Received Signal Strength Indication
    0x01,  // MARCSTATE        Main Radio Control State Machine State
    0x00,  // WORTIME1         High Byte of WOR Time
    0x00,  // WORTIME0         Low Byte of WOR Time
    0x80,  // PKTSTATUS        Current GDOx Status and Packet Status
    0xFD,  // VCO_VC_DAC       Current Setting from PLL Calibration Module
    0x00,  // TXBYTES          Underflow and Number of Bytes
    0x00,  // RXBYTES          Overflow and Number of Bytes
    0x00,  // RF1AIFCTL0       Radio interface control register 0
    0x00,  // RF1AIFCTL1       Radio interface control register 1
    0x00,  // RF1AIFCTL2       Reserved
    0x00,  // RF1AIFERR        Radio interface error flag register
    0x00,  // RF1AIFERRV       Radio interface error vector word register
    0x00,  // RF1AIFIV         Radio interface interrupt vector word register
    0x00,  // RF1AINSTRW       Radio instruction word register
    0x00,  // RF1AINSTR1W      Radio instruction word register with 1-byte auto-read (low-byte ignored)
    0x00,  // RF1AINSTR2W      Radio instruction word register with 2-byte auto-read (low-byte ignored)
    0x00,  // RF1ADINW         Radio word data in register
    0x00,  // RF1ASTAT0W       Radio status word register without auto-read
    0x00,  // RF1ASTAT1W       Radio status word register with 1-byte auto-read
    0x00,  // RF1ASTAT2W       Radio status word register with 2-byte auto-read
    0x00,  // RF1ADOUT0W       Radio core word data out register without auto-read
    0x00,  // RF1ADOUT1W       Radio core word data out register with 1-byte auto-read
    0x00,  // RF1ADOUT2W       Radio core word data out register with 2-byte auto-read
    0x00,  // RF1AIN           Radio core signal input register
    0x00,  // RF1AIFG          Radio core interrupt flag register
    0x00,  // RF1AIES          Radio core interrupt edge select register
    0x00,  // RF1AIE           Radio core interrupt enable register
    0x00,  // RF1AIV           Radio core interrupt vector word register
    0x00,  // RF1ARXFIFO       Direct receive FIFO access register
    0x00,  // RF1ATXFIFO       Direct transmit FIFO access register
};


// *************************************************************************************************
// Global Variable section


// *************************************************************************************************
// Extern section


// *************************************************************************************************
// @fn          display_cSLight
// @brief       Display cSLight: "   cSL"
// @param       u8 line	LINE2
//				u8 update	DISPLAY_LINE_UPDATE_PARTIAL, DISPLAY_LINE_UPDATE_FULL
// @return      none
// *************************************************************************************************
void display_cSLight(u8 line, u8 update)
{
	if (update == DISPLAY_LINE_UPDATE_FULL)	
	{
		display_chars(LCD_SEG_L2_5_0, (u8 *)"   ?SL", SEG_ON);
	}
}
// *************************************************************************************************
// @fn          cSL_transmit_code
// @brief       Handle RF commands to Light
// @param       none
// @return      none
// *************************************************************************************************
void cSL_transmit_code(void)
{
	volatile u16 i;
    for(i=0;i<7;i++)
    {
    	if (cSLightConfig==BEDLIGHT)  WriteBurstReg(RF_TXFIFOWR, cSLcommandBedLight,  5);
    	if (cSLightConfig==MAINLIGHT) WriteBurstReg(RF_TXFIFOWR, cSLcommandMainLight, 5);
    	Strobe(RF_STX);
    	Timer0_A4_Delay(CONV_MS_TO_TICKS(42));
    	while((Strobe(RF_SNOP)&0xF0)!=0);
    }
}

// *************************************************************************************************
// @fn          InitRadio
// @brief       Inits radio for cSLight
// @param       none
// @return      none
// *************************************************************************************************
void InitRadio(void)
{
  // Set the High-Power Mode Request Enable bit so LPM3 can be entered
  // with active radio enabled 
  PMMCTL0_H = 0xA5;
  PMMCTL0_L |= PMMHPMRE_L; 
  PMMCTL0_H = 0x00; 
  
  WriteRfSettings(&cSLrfSettings);
  WriteBurstPATable(&cSLpaTable[0],2);
  //WritePATable(0xC3);
}

// *************************************************************************************************
// @fn          sx_cSLight
// @brief       cSLight direct function. Button DOWN starts RF commands as long as button is pressed
// @param       u8 line	LINE2
// @return      none
// *************************************************************************************************
void sx_cSLight(u8 line)
{
	//volatile u8 x;
	//if(button.flag.down||button.flag.up)
	//{
		//Display RF symbol
		display_symbol(LCD_ICON_BEEPER1, SEG_ON);
		display_symbol(LCD_ICON_BEEPER2, SEG_ON);
		display_symbol(LCD_ICON_BEEPER3, SEG_ON);
		
		//Reset radio
		ResetRadioCore();
		InitRadio();
		
	    RF1AIES |= BIT9;                          
	    RF1AIFG &= ~BIT9;                         // Clear pending interrupts
	    RF1AIE &= ~BIT9;                          // Disable TX end-of-packet interrupt
	    
	    cSL_transmit_code();
	    //Transmit until button is released
		while(BUTTON_DOWN_IS_PRESSED||BUTTON_UP_IS_PRESSED)
		{
			cSL_transmit_code();
		}
		Strobe(RF_SIDLE);
		Strobe(RF_SPWD);
				
		//Clear RF symbol
		display_symbol(LCD_ICON_BEEPER1, SEG_OFF);
		display_symbol(LCD_ICON_BEEPER2, SEG_OFF);
		display_symbol(LCD_ICON_BEEPER3, SEG_OFF);
	//}
}

// *************************************************************************************************
// RF1A extensions to make cSLight run!!!!!!!!!!!!!!!!!!!!!!!!!!
// *************************************************************************************************
// *************************************************************************************************
// @fn          WriteBurstPATable
// @brief       Write to multiple locations in power table 
// @param       unsigned char *buffer	Pointer to the table of values to be written 
// @param       unsigned char count	Number of values to be written
// @return      none
// *************************************************************************************************
void WriteBurstPATable(unsigned char *buffer, unsigned char count)
{
  volatile char i = 0; 
  u16 int_state;
  
  ENTER_CRITICAL_SECTION(int_state);
  while( !(RF1AIFCTL1 & RFINSTRIFG));
  RF1AINSTRW = 0x7E00 + buffer[i];          // PA Table burst write   

  for (i = 1; i < count; i++)
  {
    RF1ADINB = buffer[i];                   // Send data
    while (!(RFDINIFG & RF1AIFCTL1));       // Wait for TX to finish
  } 
  i = RF1ADOUTB;                            // Reset RFDOUTIFG flag which contains status byte

  while( !(RF1AIFCTL1 & RFINSTRIFG));
  RF1AINSTRB = RF_SNOP;                     // reset PA Table pointer
  
  EXIT_CRITICAL_SECTION(int_state); 
}

// *****************************************************************************
// @fn          WriteRfSettings
// @brief       Write the minimum set of RF configuration register settings
// @param       RF_SETTINGS *pRfSettings  Pointer to the structure that holds the rf settings
// @return      none
// *****************************************************************************
void WriteRfSettings(RF_SETTINGS *pRfSettings) {
	WriteSingleReg(IOCFG2,   pRfSettings->iocfg2);
    WriteSingleReg(IOCFG1,   pRfSettings->iocfg1);
    WriteSingleReg(IOCFG0,   pRfSettings->iocfg0);
    WriteSingleReg(FIFOTHR,  pRfSettings->fifothr);
    WriteSingleReg(PKTLEN,   pRfSettings->pktlen);
    WriteSingleReg(PKTCTRL1, pRfSettings->pktctrl1);
    WriteSingleReg(PKTCTRL0, pRfSettings->pktctrl0);
    WriteSingleReg(ADDR,     pRfSettings->addr);
    WriteSingleReg(CHANNR,   pRfSettings->channr);
    WriteSingleReg(FREQ2,    pRfSettings->freq2);
    WriteSingleReg(FREQ1,    pRfSettings->freq1);
    WriteSingleReg(FREQ0,    pRfSettings->freq0);
    
    WriteSingleReg(MDMCFG4,  pRfSettings->mdmcfg4);
    WriteSingleReg(MDMCFG3,  pRfSettings->mdmcfg3);
    WriteSingleReg(MDMCFG2,  pRfSettings->mdmcfg2);
    WriteSingleReg(MDMCFG1,  pRfSettings->mdmcfg1);
    WriteSingleReg(MDMCFG0,  pRfSettings->mdmcfg0);
    WriteSingleReg(DEVIATN,  pRfSettings->deviatn);
    
    WriteSingleReg(MCSM0 ,   pRfSettings->mcsm0);
    WriteSingleReg(FOCCFG,   pRfSettings->foccfg);
    WriteSingleReg(BSCFG,    pRfSettings->bscfg);
    
    WriteSingleReg(FSCTRL1,  pRfSettings->fsctrl1);
    WriteSingleReg(FSCTRL0,  pRfSettings->fsctrl0);
    
    WriteSingleReg(FREND1,   pRfSettings->frend1);
    WriteSingleReg(FREND0,   pRfSettings->frend0);
    
    WriteSingleReg(FSCAL3,   pRfSettings->fscal3);
    WriteSingleReg(FSCAL2,   pRfSettings->fscal2);
    WriteSingleReg(FSCAL1,   pRfSettings->fscal1);
    WriteSingleReg(FSCAL0,   pRfSettings->fscal0);
    
    WriteSingleReg(AGCCTRL2, pRfSettings->agcctrl2);
    WriteSingleReg(AGCCTRL1, pRfSettings->agcctrl1);
    WriteSingleReg(AGCCTRL0, pRfSettings->agcctrl0);
    
    //WriteSingleReg(FSTEST,   pRfSettings->fstest);
    //WriteSingleReg(TEST2,    pRfSettings->test2);
    //WriteSingleReg(TEST1,    pRfSettings->test1);
    //WriteSingleReg(TEST0,    pRfSettings->test0); 
}
