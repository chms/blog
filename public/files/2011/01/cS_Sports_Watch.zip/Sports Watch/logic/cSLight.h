// *************************************************************************************************
// cSLight
// Extension to drive the Conrad "Funk-Lichtschalter-mit-Sender"
// http://www.conrad.at/ce/de/product/620587/Funk-Lichtschalter-mit-Sender
// (c) Christian M. Schmid
// 1.1.2011
// *************************************************************************************************
#ifndef CSLIGHT_H_
#define CSLIGHT_H_

// *************************************************************************************************
// Defines section

// Definitions
#define CSLCOMMANDLENGTH         (5)
#define BEDLIGHT                 (1)
#define MAINLIGHT                (2)

typedef struct {
    BYTE iocfg2;        // GDO2 Output Configuration
    BYTE iocfg1;        // GDO1 Output Configuration
    BYTE iocfg0;        // GDO0 Output Configuration
    BYTE fifothr;       // RX FIFO and TX FIFO Thresholds
    BYTE sync1;         // Sync Word, High Byte
    BYTE sync0;         // Sync Word, Low Byte
    BYTE pktlen;        // Packet Length
    BYTE pktctrl1;      // Packet Automation Control
    BYTE pktctrl0;      // Packet Automation Control
    BYTE addr;          // Device Address
    BYTE channr;        // Channel Number
    BYTE fsctrl1;       // Frequency Synthesizer Control
    BYTE fsctrl0;       // Frequency Synthesizer Control
    BYTE freq2;         // Frequency Control Word, High Byte
    BYTE freq1;         // Frequency Control Word, Middle Byte
    BYTE freq0;         // Frequency Control Word, Low Byte
    BYTE mdmcfg4;       // Modem Configuration
    BYTE mdmcfg3;       // Modem Configuration
    BYTE mdmcfg2;       // Modem Configuration
    BYTE mdmcfg1;       // Modem Configuration
    BYTE mdmcfg0;       // Modem Configuration
    BYTE deviatn;       // Modem Deviation Setting
    BYTE mcsm2;         // Main Radio Control State Machine Configuration
    BYTE mcsm1;         // Main Radio Control State Machine Configuration
    BYTE mcsm0;         // Main Radio Control State Machine Configuration
    BYTE foccfg;        // Frequency Offset Compensation Configuration
    BYTE bscfg;         // Bit Synchronization Configuration
    BYTE agcctrl2;      // AGC Control
    BYTE agcctrl1;      // AGC Control
    BYTE agcctrl0;      // AGC Control
    BYTE worevt1;       // High Byte Event0 Timeout
    BYTE worevt0;       // Low Byte Event0 Timeout
    BYTE worctrl;       // Wake On Radio Control
    BYTE frend1;        // Front End RX Configuration
    BYTE frend0;        // Front End TX Configuration
    BYTE fscal3;        // Frequency Synthesizer Calibration
    BYTE fscal2;        // Frequency Synthesizer Calibration
    BYTE fscal1;        // Frequency Synthesizer Calibration
    BYTE fscal0;        // Frequency Synthesizer Calibration
    BYTE fstest;        // Frequency Synthesizer Calibration Control
    BYTE ptest;         // Production Test
    BYTE agctest;       // AGC Test
//    BYTE test2;         // Various Test Settings
//    BYTE test1;         // Various Test Settings
//    BYTE test0;         // Various Test Settings
    BYTE partnum;       // Chip ID
    BYTE version;       // Chip ID
    BYTE freqest;       // Frequency Offset Estimate From Demodulator
    BYTE lqi;           // Demodulator Estimate for Link Quality
    BYTE rssi;          // Received Signal Strength Indication
    BYTE marcstate;     // Main Radio Control State Machine State
    BYTE wortime1;      // High Byte of WOR Time
    BYTE wortime0;      // Low Byte of WOR Time
    BYTE pktstatus;     // Current GDOx Status and Packet Status
    BYTE vco_vc_dac;    // Current Setting from PLL Calibration Module
    BYTE txbytes;       // Underflow and Number of Bytes
    BYTE rxbytes;       // Overflow and Number of Bytes
    BYTE rf1aifctl0;    // Radio interface control register 0
    BYTE rf1aifctl1;    // Radio interface control register 1
    BYTE rf1aifctl2;    // Reserved
    BYTE rf1aiferr;     // Radio interface error flag register
    BYTE rf1aiferrv;    // Radio interface error vector word register
    BYTE rf1aifiv;      // Radio interface interrupt vector word register
    BYTE rf1ainstrw;    // Radio instruction word register
    BYTE rf1ainstr1w;   // Radio instruction word register with 1-byte auto-read (low-byte ignored)
    BYTE rf1ainstr2w;   // Radio instruction word register with 2-byte auto-read (low-byte ignored)
    BYTE rf1adinw;      // Radio word data in register
    BYTE rf1astat0w;    // Radio status word register without auto-read
    BYTE rf1astat1w;    // Radio status word register with 1-byte auto-read
    BYTE rf1astat2w;    // Radio status word register with 2-byte auto-read
    BYTE rf1adout0w;    // Radio core word data out register without auto-read
    BYTE rf1adout1w;    // Radio core word data out register with 1-byte auto-read
    BYTE rf1adout2w;    // Radio core word data out register with 2-byte auto-read
    BYTE rf1ain;        // Radio core signal input register
    BYTE rf1aifg;       // Radio core interrupt flag register
    BYTE rf1aies;       // Radio core interrupt edge select register
    BYTE rf1aie;        // Radio core interrupt enable register
    BYTE rf1aiv;        // Radio core interrupt vector word register
    BYTE rf1arxfifo;    // Direct receive FIFO access register
    BYTE rf1atxfifo;    // Direct transmit FIFO access register
} RF_SETTINGS;



// *************************************************************************************************
// Prototypes section
extern void cSL_transmit_code(void);
extern void sx_cSLight(u8 line);
//extern void mx_cSLight(u8 line);
extern void display_cSLight(u8 line, u8 update);
extern void InitRadio(void);
extern void WriteBurstPATable(unsigned char *buffer, unsigned char count);
extern void WriteRfSettings(RF_SETTINGS *pRfSettings);

// *************************************************************************************************
// Global Variable section
extern volatile u8 cSLightConfig;

#endif /*CSLIGHT_H_*/
