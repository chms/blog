function [bytes] = breakBytes(data)
% Break an arbitrary stream of bits into packages of 8 bits.
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2011
% http:\\chronos.chschmid.com
%--------------------------------------------------------------------------
% Example:
% breakBytes('010101010101') will produce
% bytes=['01010101'
%        '01010000']
%--------------------------------------------------------------------------

nbits=length(data);          %Number of bits
nbytes=ceil(length(data)/8); %Number of bytes in bit stream
bytes=char(zeros(nbytes,8)); %Init byte array

k3=1;
for k1=1:nbytes              
    for k2=1:8               
        if k3<=nbits
            bytes(k1,k2)=data(k3);
        else
            bytes(k1,k2)='0'; %Fill last byte with 0s when no mor bits available
        end
        k3=k3+1;
    end
end

end

