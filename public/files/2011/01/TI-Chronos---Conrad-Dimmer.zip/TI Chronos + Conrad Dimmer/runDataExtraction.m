% Load measurement data and extract command to send by the TI chronos
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2011
% http:\\chronos.chschmid.com
%--------------------------------------------------------------------------

clear all;
close all;
clc;

%Load data file
load('HT12Edata.mat');

%Plot time domain signal
figure(1)
plot(tHT12E*1e3,VHT12E);
grid on;
xlabel('Time (ms)');
ylabel('Voltage (V)');
title('Raw data (multiple command cycles)');
%% Determine data timing
Vhigh=8;
Vtrans=4;
Vlow=1;

%Find first positive edge
k1=find(VHT12E>Vtrans,1);
t1=tHT12E(k1);

%Find find negative edge
k2=find(VHT12E(k1:end)<Vtrans,1)+k1-1;
t2=tHT12E(k2);

dt=t2-t1;    %Bit duration in s
dk=k2-k1;  %Bit duration in samples

%Cut previous data
VHT12E=VHT12E((k1-2*dk):end);
tHT12E=tHT12E((k1-2*dk):end);
tHT12E=tHT12E-min(tHT12E);

%% Sample data for data extraction
ncommands=4; %Number of command cycles to extract
samplepoints=zeros(71*ncommands*dk,1);
for k3=1:ceil(71/8*ncommands)
    for k4=1:8
        kx=((k3-1)*8+k4-1)*dk+round(dk/2);
        samplepoints(kx)=10;
        if(VHT12E(kx)<Vtrans)
            bytedata(k3,k4)='0';
            data((k3-1)*8+k4)='0';
        else
            bytedata(k3,k4)='1';
            data((k3-1)*8+k4)='1';
        end
    end
end

%Plot single command and sample points
figure(2)
plot(samplepoints);
hold on;
plot(VHT12E,'r','Linewidth',2);
grid on;
xlabel('Number of sample (1)');
ylabel('Voltage (V)');
xlim([0,1600]);
title('Zoom into a single command');

%Convert command to hex commands for CC430
command=data(1:71);
mspdataonoff=[command,command,command,command,command,command];
mspdataonoff=buildMSPhex(mspdataonoff)

mspdatalongpress=repmat(command,[1,10]);
mspdatalongpress=buildMSPhex(mspdatalongpress);