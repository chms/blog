% Calculate data for one signal cycle for the TI chronos from the solder
% mask (emulating the HT12E encoder)
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2011
% http:\\chronos.chschmid.com
%--------------------------------------------------------------------------

soldermask='011001100000'; %Bed light
soldermask='101110010000'; %Main light

%Calculate
code=['0',soldermask];  %HT12E adds on zero
ncode=length(code);

%HT12E makes solder1->001 and solder0->001
bincode=char(zeros(1,ncode*3));
for k1=1:ncode
    if(code(k1)=='1')
        bincode((k1*3-2):(k1*3))='011';
    else
        bincode((k1*3-2):(k1*3))='001';
    end
end

bincode=[bincode,'00000000'];
nbytes=ceil(ncode*3/8);

HT12Ehex=buildMSPhex(bincode);
HT12Ehex