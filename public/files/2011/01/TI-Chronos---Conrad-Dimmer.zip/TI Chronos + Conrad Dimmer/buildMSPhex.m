function [hexcode] = buildMSPhex(data)
% Builds a hex command string from a arbitrary binary bit string to be used in TI SmartRF Studio
%--------------------------------------------------------------------------
% (c) Christian M. Schmid, 2011
% http:\\chronos.chschmid.com
%--------------------------------------------------------------------------
% Example:
% buildMSPhex('01010101010100000000000000000010000010') will produce
% hexcode='55 50 00 02 08'
%--------------------------------------------------------------------------
    
data=dec2hex(bin2dec(breakBytes(data)));  %Convert bitstream to hex
m=size(data,1);                           %Number of words (2bytes)

hexcode=char(ones(1,3*m-1)*' ');          %Init output string variable
for k1=1:m
    hexcode((k1*3-2):(k1*3-1))=data(k1,:);%Fill output string
end
end